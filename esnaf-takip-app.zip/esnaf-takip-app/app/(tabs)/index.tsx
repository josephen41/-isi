import React, { useState, useEffect, useCallback } from 'react';
import { StyleSheet, View, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { Text, Card, useTheme, ActivityIndicator } from 'react-native-paper';
import { useFocusEffect, router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { getDashboardStats } from '@/utils/asyncStorage';
import { initializeStorage } from '@/utils/asyncStorage';

export default function DashboardScreen() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    customersCount: 0,
    suppliersCount: 0,
    productsCount: 0,
    transactionsCount: 0,
    totalEarnings: 0,
    totalExpenses: 0,
    profit: 0,
    recentTransactions: []
  });
  const theme = useTheme();

  // Initialize storage on first load
  useEffect(() => {
    initializeStorage();
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadDashboardData();
    }, [])
  );

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const dashboardData = await getDashboardStats();
      setStats(dashboardData);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);
  };

  if (loading && !refreshing) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  const navigateToTransactionForm = () => {
    router.push('/transaction-form');
  };

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Esnaf Takip</Text>
        <Text style={styles.headerSubtitle}>Genel Durum</Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Finansal Durum</Text>
        <View style={styles.financialCards}>
          <Card style={[styles.financialCard, { backgroundColor: '#e8f5e9' }]}>
            <Card.Content>
              <Text style={styles.cardLabel}>Toplam Alacak</Text>
              <Text style={[styles.cardValue, { color: '#2e7d32' }]}>
                {formatCurrency(stats.totalEarnings)}
              </Text>
            </Card.Content>
          </Card>
          
          <Card style={[styles.financialCard, { backgroundColor: '#ffebee' }]}>
            <Card.Content>
              <Text style={styles.cardLabel}>Toplam Borç</Text>
              <Text style={[styles.cardValue, { color: '#c62828' }]}>
                {formatCurrency(stats.totalExpenses)}
              </Text>
            </Card.Content>
          </Card>
          
          <Card style={[styles.financialCard, { backgroundColor: stats.profit >= 0 ? '#e3f2fd' : '#fce4ec' }]}>
            <Card.Content>
              <Text style={styles.cardLabel}>Net Durum</Text>
              <Text style={[styles.cardValue, { color: stats.profit >= 0 ? '#1565c0' : '#c2185b' }]}>
                {formatCurrency(stats.profit)}
              </Text>
            </Card.Content>
          </Card>
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Özet Bilgiler</Text>
        <View style={styles.statsGrid}>
          <TouchableOpacity 
            style={styles.statsCard}
            onPress={() => router.push('/customers')}
          >
            <View style={[styles.statsIconContainer, { backgroundColor: '#bbdefb' }]}>
              <MaterialCommunityIcons name="account-group" size={24} color="#1565c0" />
            </View>
            <Text style={styles.statsValue}>{stats.customersCount}</Text>
            <Text style={styles.statsLabel}>Müşteri</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.statsCard}
            onPress={() => router.push('/suppliers')}
          >
            <View style={[styles.statsIconContainer, { backgroundColor: '#ffecb3' }]}>
              <MaterialCommunityIcons name="truck" size={24} color="#ff8f00" />
            </View>
            <Text style={styles.statsValue}>{stats.suppliersCount}</Text>
            <Text style={styles.statsLabel}>Tedarikçi</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.statsCard}
            onPress={() => router.push('/products')}
          >
            <View style={[styles.statsIconContainer, { backgroundColor: '#c8e6c9' }]}>
              <MaterialCommunityIcons name="package-variant-closed" size={24} color="#2e7d32" />
            </View>
            <Text style={styles.statsValue}>{stats.productsCount}</Text>
            <Text style={styles.statsLabel}>Ürün</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.statsCard}
            onPress={() => router.push('/transactions')}
          >
            <View style={[styles.statsIconContainer, { backgroundColor: '#e1bee7' }]}>
              <MaterialCommunityIcons name="cash-multiple" size={24} color="#7b1fa2" />
            </View>
            <Text style={styles.statsValue}>{stats.transactionsCount}</Text>
            <Text style={styles.statsLabel}>İşlem</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Son İşlemler</Text>
          <TouchableOpacity onPress={() => router.push('/transactions')}>
            <Text style={styles.viewAllLink}>Tümünü Gör</Text>
          </TouchableOpacity>
        </View>
        
        {stats.recentTransactions.length === 0 ? (
          <Card style={styles.emptyCard}>
            <Card.Content style={styles.emptyCardContent}>
              <MaterialCommunityIcons name="cash-remove" size={40} color="#ccc" />
              <Text style={styles.emptyText}>Henüz işlem kaydı bulunmamaktadır</Text>
              <TouchableOpacity 
                style={styles.addButton}
                onPress={navigateToTransactionForm}
              >
                <Text style={styles.addButtonText}>İşlem Ekle</Text>
              </TouchableOpacity>
            </Card.Content>
          </Card>
        ) : (
          <>
            {stats.recentTransactions.map((transaction) => (
              <Card
                key={transaction.id}
                style={styles.transactionCard}
                onPress={() => {
                  if (transaction.type === 'customer') {
                    router.push({
                      pathname: '/customer-details',
                      params: { customerId: transaction.customerOrSupplierId }
                    });
                  } else {
                    router.push({
                      pathname: '/supplier-details',
                      params: { supplierId: transaction.customerOrSupplierId }
                    });
                  }
                }}
              >
                <Card.Content>
                  <View style={styles.transactionHeader}>
                    <Text style={styles.transactionDate}>
                      {new Date(transaction.date).toLocaleDateString('tr-TR')}
                    </Text>
                    <View style={[
                      styles.transactionTypeTag,
                      { backgroundColor: transaction.type === 'customer' ? '#e8f5e9' : '#ffebee' }
                    ]}>
                      <Text style={{
                        color: transaction.type === 'customer' ? '#2e7d32' : '#c62828',
                        fontWeight: '500',
                        fontSize: 12
                      }}>
                        {transaction.type === 'customer' ? 'Alacak' : 'Borç'}
                      </Text>
                    </View>
                  </View>
                  
                  <Text style={styles.transactionEntity} numberOfLines={1}>
                    {transaction.entityName || 'İsimsiz'}
                  </Text>
                  
                  {transaction.description && (
                    <Text style={styles.transactionDesc} numberOfLines={1}>
                      {transaction.description}
                    </Text>
                  )}
                  
                  <Text
                    style={[
                      styles.transactionAmount,
                      {
                        color: transaction.type === 'customer' ? '#2e7d32' : '#c62828',
                      },
                    ]}
                  >
                    {transaction.type === 'customer' ? '+' : '-'} {formatCurrency(transaction.amount)}
                  </Text>
                </Card.Content>
              </Card>
            ))}
          </>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: 16,
    backgroundColor: '#fff',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  section: {
    marginBottom: 16,
    padding: 16,
    backgroundColor: 'white',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  viewAllLink: {
    color: '#007AFF',
  },
  financialCards: {
    flexDirection: 'column',
    gap: 10,
  },
  financialCard: {
    marginBottom: 8,
  },
  cardLabel: {
    fontSize: 14,
    color: '#666',
  },
  cardValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statsCard: {
    width: '48%',
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    alignItems: 'center',
  },
  statsIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statsValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  statsLabel: {
    color: '#666',
    marginTop: 4,
  },
  transactionCard: {
    marginBottom: 8,
  },
  transactionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  transactionDate: {
    fontSize: 12,
    color: '#666',
  },
  transactionTypeTag: {
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 4,
  },
  transactionEntity: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  transactionDesc: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 4,
    textAlign: 'right',
  },
  emptyCard: {
    padding: 12,
  },
  emptyCardContent: {
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 12,
    color: '#666',
    textAlign: 'center',
  },
  addButton: {
    marginTop: 16,
    backgroundColor: '#007AFF',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});