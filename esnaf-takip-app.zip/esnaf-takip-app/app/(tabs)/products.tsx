import React, { useEffect, useState } from 'react';
import { StyleSheet, View, FlatList, RefreshControl } from 'react-native';
import { 
  Text, FAB, Searchbar, Card, Divider, IconButton, 
  Menu, Button, Dialog, Portal, useTheme, ActivityIndicator
} from 'react-native-paper';
import { router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { getProducts, deleteProduct } from '@/utils/asyncStorage';

export default function ProductsScreen() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const theme = useTheme();

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredProducts(products);
    } else {
      const filtered = products.filter(
        product => product.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  }, [searchQuery, products]);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const productsData = await getProducts();
      const sortedProducts = [...productsData].sort((a, b) => a.name.localeCompare(b.name));
      setProducts(sortedProducts);
      setFilteredProducts(sortedProducts);
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadProducts();
    setRefreshing(false);
  };

  const onSearch = (query) => {
    setSearchQuery(query);
  };

  const openMenu = (product) => {
    setSelectedProduct(product);
    setMenuVisible(true);
  };

  const closeMenu = () => {
    setMenuVisible(false);
  };

  const openDeleteDialog = () => {
    closeMenu();
    setDeleteDialogVisible(true);
  };

  const handleEdit = () => {
    closeMenu();
    if (selectedProduct) {
      router.push({
        pathname: '/product-form',
        params: { productId: selectedProduct.id }
      });
    }
  };

  const handleDelete = async () => {
    try {
      if (selectedProduct) {
        await deleteProduct(selectedProduct.id);
        loadProducts();
      }
    } catch (error) {
      console.error('Error deleting product:', error);
    } finally {
      setDeleteDialogVisible(false);
    }
  };

  const handleAddNew = () => {
    router.push('/product-form');
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);
  };

  if (loading && !refreshing) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  const renderProductCard = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.cardHeader}>
          <View>
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productCategory}>{item.category || 'Kategori belirtilmedi'}</Text>
          </View>
          <IconButton
            icon="dots-vertical"
            onPress={() => openMenu(item)}
          />
        </View>
        <Divider style={styles.divider} />
        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <MaterialCommunityIcons name="tag" size={18} color="#666" />
            <Text style={styles.detailText}>
              {formatCurrency(item.price)}
            </Text>
          </View>
          <View style={styles.detailItem}>
            <MaterialCommunityIcons name="package-variant" size={18} color="#666" />
            <Text style={styles.detailText}>
              Stok: {item.stock || 0}
            </Text>
          </View>
        </View>
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Ürün Ara"
        onChangeText={onSearch}
        value={searchQuery}
        style={styles.searchBar}
      />
      
      {filteredProducts.length === 0 ? (
        <View style={styles.emptyContainer}>
          <MaterialCommunityIcons name="package-variant-closed-search" size={64} color="#ccc" />
          <Text style={styles.emptyText}>
            {searchQuery ? 'Arama sonucu bulunamadı' : 'Henüz ürün kaydı bulunmamaktadır'}
          </Text>
          {searchQuery && (
            <Button
              mode="contained"
              onPress={() => setSearchQuery('')}
              style={styles.clearSearchButton}
            >
              Aramayı Temizle
            </Button>
          )}
        </View>
      ) : (
        <FlatList
          data={filteredProducts}
          renderItem={renderProductCard}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      )}
      
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={handleAddNew}
      />

      <Menu
        visible={menuVisible}
        onDismiss={closeMenu}
        anchor={{ x: 0, y: 0 }}
        style={styles.menu}
      >
        <Menu.Item
          leadingIcon="pencil"
          onPress={handleEdit}
          title="Düzenle"
        />
        <Menu.Item
          leadingIcon="delete"
          onPress={openDeleteDialog}
          title="Sil"
          titleStyle={{ color: 'red' }}
        />
      </Menu>

      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>Ürünü Sil</Dialog.Title>
          <Dialog.Content>
            <Text>
              "{selectedProduct?.name}" isimli ürünü silmek istediğinize emin misiniz?
              Bu işlem geri alınamaz.
            </Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>İptal</Button>
            <Button onPress={handleDelete} textColor="red">Sil</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchBar: {
    margin: 16,
    elevation: 2,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  card: {
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productCategory: {
    color: '#666',
    marginTop: 4,
  },
  divider: {
    marginVertical: 8,
  },
  detailsRow: {
    flexDirection: 'row',
    marginTop: 4,
    justifyContent: 'space-between',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  detailText: {
    marginLeft: 6,
    color: '#666',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
  menu: {
    position: 'absolute',
    right: 24,
    top: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  clearSearchButton: {
    marginTop: 16,
  },
});