import React, { useEffect, useState } from 'react';
import { StyleSheet, View, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { 
  Text, FAB, Searchbar, Card, Divider, IconButton, 
  Menu, Button, Dialog, Portal, useTheme, ActivityIndicator
} from 'react-native-paper';
import { router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { getSuppliers, deleteSupplier } from '@/utils/asyncStorage';

export default function SuppliersScreen() {
  const [suppliers, setSuppliers] = useState([]);
  const [filteredSuppliers, setFilteredSuppliers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const theme = useTheme();

  useEffect(() => {
    loadSuppliers();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredSuppliers(suppliers);
    } else {
      const filtered = suppliers.filter(
        supplier => supplier.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredSuppliers(filtered);
    }
  }, [searchQuery, suppliers]);

  const loadSuppliers = async () => {
    try {
      setLoading(true);
      const suppliersData = await getSuppliers();
      const sortedSuppliers = [...suppliersData].sort((a, b) => a.name.localeCompare(b.name));
      setSuppliers(sortedSuppliers);
      setFilteredSuppliers(sortedSuppliers);
    } catch (error) {
      console.error('Error loading suppliers:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadSuppliers();
    setRefreshing(false);
  };

  const onSearch = (query) => {
    setSearchQuery(query);
  };

  const openMenu = (supplier) => {
    setSelectedSupplier(supplier);
    setMenuVisible(true);
  };

  const closeMenu = () => {
    setMenuVisible(false);
  };

  const openDeleteDialog = () => {
    closeMenu();
    setDeleteDialogVisible(true);
  };

  const handleEdit = () => {
    closeMenu();
    if (selectedSupplier) {
      router.push({
        pathname: '/supplier-form',
        params: { supplierId: selectedSupplier.id }
      });
    }
  };

  const handleDelete = async () => {
    try {
      if (selectedSupplier) {
        await deleteSupplier(selectedSupplier.id);
        loadSuppliers();
      }
    } catch (error) {
      console.error('Error deleting supplier:', error);
    } finally {
      setDeleteDialogVisible(false);
    }
  };

  const handleAddNew = () => {
    router.push('/supplier-form');
  };

  const handleViewDetails = (supplier) => {
    router.push({
      pathname: '/supplier-details',
      params: { supplierId: supplier.id }
    });
  };

  if (loading && !refreshing) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  const renderSupplierCard = ({ item }) => (
    <Card style={styles.card} onPress={() => handleViewDetails(item)}>
      <Card.Content>
        <View style={styles.cardHeader}>
          <View>
            <Text style={styles.supplierName}>{item.name}</Text>
            <Text style={styles.supplierPhone}>{item.phone}</Text>
          </View>
          <IconButton
            icon="dots-vertical"
            onPress={() => openMenu(item)}
          />
        </View>
        <Divider style={styles.divider} />
        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <MaterialCommunityIcons name="map-marker" size={18} color="#666" />
            <Text style={styles.detailText} numberOfLines={1}>
              {item.address || 'Adres belirtilmedi'}
            </Text>
          </View>
        </View>
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Tedarikçi Ara"
        onChangeText={onSearch}
        value={searchQuery}
        style={styles.searchBar}
      />
      
      {filteredSuppliers.length === 0 ? (
        <View style={styles.emptyContainer}>
          <MaterialCommunityIcons name="truck-check" size={64} color="#ccc" />
          <Text style={styles.emptyText}>
            {searchQuery ? 'Arama sonucu bulunamadı' : 'Henüz tedarikçi kaydı bulunmamaktadır'}
          </Text>
          {searchQuery && (
            <Button
              mode="contained"
              onPress={() => setSearchQuery('')}
              style={styles.clearSearchButton}
            >
              Aramayı Temizle
            </Button>
          )}
        </View>
      ) : (
        <FlatList
          data={filteredSuppliers}
          renderItem={renderSupplierCard}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      )}
      
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={handleAddNew}
      />

      <Menu
        visible={menuVisible}
        onDismiss={closeMenu}
        anchor={{ x: 0, y: 0 }}
        style={styles.menu}
      >
        <Menu.Item
          leadingIcon="pencil"
          onPress={handleEdit}
          title="Düzenle"
        />
        <Menu.Item
          leadingIcon="delete"
          onPress={openDeleteDialog}
          title="Sil"
          titleStyle={{ color: 'red' }}
        />
      </Menu>

      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>Tedarikçiyi Sil</Dialog.Title>
          <Dialog.Content>
            <Text>
              "{selectedSupplier?.name}" isimli tedarikçiyi silmek istediğinize emin misiniz?
              Bu işlem geri alınamaz ve tedarikçiye ait tüm işlem kayıtları da silinecektir.
            </Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>İptal</Button>
            <Button onPress={handleDelete} textColor="red">Sil</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchBar: {
    margin: 16,
    elevation: 2,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  card: {
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  supplierName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  supplierPhone: {
    color: '#666',
    marginTop: 4,
  },
  divider: {
    marginVertical: 8,
  },
  detailsRow: {
    flexDirection: 'row',
    marginTop: 4,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
    flex: 1,
  },
  detailText: {
    marginLeft: 6,
    color: '#666',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
  menu: {
    position: 'absolute',
    right: 24,
    top: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  clearSearchButton: {
    marginTop: 16,
  },
});