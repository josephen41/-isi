import React, { useState, useEffect } from 'react';
import { StyleSheet, View, FlatList, RefreshControl } from 'react-native';
import { 
  Text, Searchbar, Card, Divider, useTheme, ActivityIndicator,
  Chip, Button, Menu, Portal, Dialog, SegmentedButtons 
} from 'react-native-paper';
import { router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { getAllTransactions, deleteTransaction } from '@/utils/asyncStorage';

export default function TransactionsScreen() {
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filterType, setFilterType] = useState('all'); // 'all', 'customer', 'supplier'
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const theme = useTheme();

  useEffect(() => {
    loadTransactions();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [searchQuery, transactions, filterType]);

  const loadTransactions = async () => {
    try {
      setLoading(true);
      const transactionsData = await getAllTransactions();
      // Sort by date, most recent first
      const sortedTransactions = [...transactionsData].sort(
        (a, b) => new Date(b.date) - new Date(a.date)
      );
      setTransactions(sortedTransactions);
    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterTransactions = () => {
    let filtered = [...transactions];
    
    // Apply type filter
    if (filterType !== 'all') {
      filtered = filtered.filter(transaction => transaction.type === filterType);
    }
    
    // Apply search filter
    if (searchQuery.trim()) {
      filtered = filtered.filter(
        transaction => 
          transaction.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          transaction.entityName?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    setFilteredTransactions(filtered);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTransactions();
    setRefreshing(false);
  };

  const onSearch = (query) => {
    setSearchQuery(query);
  };

  const openMenu = (transaction) => {
    setSelectedTransaction(transaction);
    setMenuVisible(true);
  };

  const closeMenu = () => {
    setMenuVisible(false);
  };

  const confirmDelete = () => {
    closeMenu();
    setDeleteDialogVisible(true);
  };

  const handleDelete = async () => {
    try {
      if (selectedTransaction) {
        await deleteTransaction(selectedTransaction.id);
        loadTransactions();
      }
    } catch (error) {
      console.error('Error deleting transaction:', error);
    } finally {
      setDeleteDialogVisible(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);
  };

  const getEntityPath = (transaction) => {
    if (transaction.type === 'customer') {
      return {
        pathname: '/customer-details',
        params: { customerId: transaction.customerOrSupplierId }
      };
    } else {
      return {
        pathname: '/supplier-details',
        params: { supplierId: transaction.customerOrSupplierId }
      };
    }
  };

  const renderTransactionItem = ({ item }) => (
    <Card style={styles.card} onPress={() => router.push(getEntityPath(item))}>
      <Card.Content>
        <View style={styles.cardHeader}>
          <View style={styles.headerLeft}>
            <Chip 
              mode="outlined"
              style={[
                styles.typeChip, 
                { 
                  backgroundColor: item.type === 'customer' ? '#e8f5e9' : '#ffebee',
                  borderColor: item.type === 'customer' ? '#4caf50' : '#f44336'
                }
              ]}
              textStyle={{
                color: item.type === 'customer' ? '#4caf50' : '#f44336'
              }}
            >
              {item.type === 'customer' ? 'Alacak' : 'Borç'}
            </Chip>
            <Text style={styles.date}>
              {new Date(item.date).toLocaleDateString('tr-TR')}
            </Text>
          </View>
          <Button
            icon="dots-vertical"
            mode="text"
            onPress={() => openMenu(item)}
          />
        </View>
        
        <View style={styles.entityRow}>
          <MaterialCommunityIcons 
            name={item.type === 'customer' ? 'account' : 'truck'} 
            size={20} 
            color="#666" 
          />
          <Text style={styles.entityName}>{item.entityName || 'Belirsiz'}</Text>
        </View>
        
        {item.description && (
          <Text style={styles.description} numberOfLines={2}>
            {item.description}
          </Text>
        )}
        
        <Divider style={styles.divider} />
        
        <Text 
          style={[
            styles.amount,
            { color: item.type === 'customer' ? '#4caf50' : '#f44336' }
          ]}
        >
          {item.type === 'customer' ? '+' : '-'} {formatCurrency(item.amount)}
        </Text>
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <View style={styles.filterContainer}>
        <Searchbar
          placeholder="İşlem Ara"
          onChangeText={onSearch}
          value={searchQuery}
          style={styles.searchBar}
        />
        
        <SegmentedButtons
          value={filterType}
          onValueChange={setFilterType}
          buttons={[
            {
              value: 'all',
              label: 'Tümü'
            },
            {
              value: 'customer',
              label: 'Alacak'
            },
            {
              value: 'supplier',
              label: 'Borç'
            },
          ]}
          style={styles.segmentedButtons}
        />
      </View>
      
      {loading && !refreshing ? (
        <View style={[styles.container, styles.centered]}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
        </View>
      ) : filteredTransactions.length === 0 ? (
        <View style={styles.emptyContainer}>
          <MaterialCommunityIcons name="cash-remove" size={64} color="#ccc" />
          <Text style={styles.emptyText}>
            {searchQuery || filterType !== 'all'
              ? 'Arama kriterlerinize uygun işlem bulunamadı'
              : 'Henüz işlem kaydı bulunmamaktadır'}
          </Text>
          {(searchQuery || filterType !== 'all') && (
            <Button
              mode="contained"
              onPress={() => {
                setSearchQuery('');
                setFilterType('all');
              }}
              style={styles.clearFiltersButton}
            >
              Filtreleri Temizle
            </Button>
          )}
        </View>
      ) : (
        <FlatList
          data={filteredTransactions}
          renderItem={renderTransactionItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      )}

      <Menu
        visible={menuVisible}
        onDismiss={closeMenu}
        anchor={{ x: 0, y: 0 }}
        style={styles.menu}
      >
        <Menu.Item
          leadingIcon="delete"
          onPress={confirmDelete}
          title="Sil"
          titleStyle={{ color: 'red' }}
        />
      </Menu>

      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>İşlemi Sil</Dialog.Title>
          <Dialog.Content>
            <Text>
              Bu işlemi silmek istediğinize emin misiniz?
              Bu işlem geri alınamaz.
            </Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>İptal</Button>
            <Button onPress={handleDelete} textColor="red">Sil</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterContainer: {
    padding: 16,
    paddingBottom: 8,
  },
  searchBar: {
    marginBottom: 8,
  },
  segmentedButtons: {
    marginBottom: 8,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  card: {
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  typeChip: {
    height: 28,
    marginRight: 8,
  },
  date: {
    color: '#666',
  },
  entityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  entityName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  description: {
    marginTop: 4,
    color: '#666',
  },
  divider: {
    marginVertical: 8,
  },
  amount: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  menu: {
    position: 'absolute',
    right: 24,
    top: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  clearFiltersButton: {
    marginTop: 16,
  },
});