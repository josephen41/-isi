import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, RefreshControl } from 'react-native';
import { 
  Text, Card, IconButton, Button, Title, Paragraph, 
  Divider, Dialog, Portal, useTheme, ActivityIndicator,
  FAB
} from 'react-native-paper';
import { useLocalSearchParams, router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { 
  getCustomerById, deleteCustomer, getTransactionsByEntityId,
  addTransaction
} from '@/utils/asyncStorage';

export default function CustomerDetailsScreen() {
  const { customerId } = useLocalSearchParams();
  const theme = useTheme();
  const [customer, setCustomer] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const [addPaymentDialogVisible, setAddPaymentDialogVisible] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentDescription, setPaymentDescription] = useState('');
  const [isSavingPayment, setIsSavingPayment] = useState(false);

  useEffect(() => {
    if (customerId) {
      loadData();
    }
  }, [customerId]);

  const loadData = async () => {
    try {
      const customerData = await getCustomerById(customerId);
      if (customerData) {
        setCustomer(customerData);
        const customerTransactions = await getTransactionsByEntityId(customerId, 'customer');
        setTransactions(customerTransactions.sort((a, b) => new Date(b.date) - new Date(a.date)));
      } else {
        console.error('Customer not found');
        router.back();
      }
    } catch (error) {
      console.error('Error loading customer details:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleEdit = () => {
    router.push({
      pathname: '/customer-form',
      params: { customerId }
    });
  };

  const confirmDelete = () => {
    setDeleteDialogVisible(true);
  };

  const handleDelete = async () => {
    try {
      await deleteCustomer(customerId);
      setDeleteDialogVisible(false);
      router.back();
    } catch (error) {
      console.error('Error deleting customer:', error);
    }
  };

  const openAddPaymentDialog = () => {
    setAddPaymentDialogVisible(true);
  };

  const handleAddPayment = async () => {
    if (!paymentAmount) return;

    try {
      setIsSavingPayment(true);
      const amount = parseFloat(paymentAmount);
      
      if (isNaN(amount) || amount <= 0) {
        alert('Lütfen geçerli bir miktar giriniz');
        return;
      }

      await addTransaction({
        amount,
        description: paymentDescription || `${customer.name} - Ödeme`,
        type: 'customer',
        customerOrSupplierId: customerId,
        date: new Date().toISOString()
      });

      setAddPaymentDialogVisible(false);
      setPaymentAmount('');
      setPaymentDescription('');
      onRefresh();
    } catch (error) {
      console.error('Error adding payment:', error);
    } finally {
      setIsSavingPayment(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);
  };

  const calculateTotalPayments = () => {
    return transactions.reduce((total, transaction) => total + parseFloat(transaction.amount), 0);
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={styles.header}>
          <Text style={styles.name}>{customer.name}</Text>
          <View style={styles.headerActions}>
            <IconButton 
              icon="pencil" 
              size={24} 
              onPress={handleEdit} 
              style={styles.actionButton}
            />
            <IconButton 
              icon="delete" 
              size={24} 
              onPress={confirmDelete} 
              style={styles.actionButton} 
            />
          </View>
        </View>

        <Card style={styles.infoCard}>
          <Card.Content>
            <View style={styles.infoRow}>
              <MaterialCommunityIcons name="phone" size={20} color="#666" />
              <Text style={styles.infoText}>{customer.phone}</Text>
            </View>
            {customer.email && (
              <View style={styles.infoRow}>
                <MaterialCommunityIcons name="email" size={20} color="#666" />
                <Text style={styles.infoText}>{customer.email}</Text>
              </View>
            )}
            {customer.address && (
              <View style={styles.infoRow}>
                <MaterialCommunityIcons name="map-marker" size={20} color="#666" />
                <Text style={styles.infoText}>{customer.address}</Text>
              </View>
            )}
            {customer.notes && (
              <View style={styles.infoRow}>
                <MaterialCommunityIcons name="note-text" size={20} color="#666" />
                <Text style={styles.infoText}>{customer.notes}</Text>
              </View>
            )}
          </Card.Content>
        </Card>

        <Card style={styles.summaryCard}>
          <Card.Content>
            <Title>Toplam İşlem</Title>
            <Paragraph style={styles.totalAmount}>
              {formatCurrency(calculateTotalPayments())}
            </Paragraph>
          </Card.Content>
        </Card>

        <Card style={styles.transactionsCard}>
          <Card.Content>
            <Title style={styles.sectionTitle}>İşlem Geçmişi</Title>
            
            {transactions.length === 0 ? (
              <Text style={styles.emptyText}>Henüz işlem kaydı bulunmamaktadır</Text>
            ) : (
              transactions.map((transaction, index) => (
                <React.Fragment key={transaction.id}>
                  <View style={styles.transactionItem}>
                    <View style={styles.transactionDetails}>
                      <Text style={styles.transactionDescription}>
                        {transaction.description || 'Ödeme'}
                      </Text>
                      <Text style={styles.transactionDate}>
                        {new Date(transaction.date).toLocaleDateString('tr-TR')}
                      </Text>
                    </View>
                    <Text style={styles.transactionAmount}>
                      {formatCurrency(transaction.amount)}
                    </Text>
                  </View>
                  {index < transactions.length - 1 && <Divider style={styles.divider} />}
                </React.Fragment>
              ))
            )}
          </Card.Content>
        </Card>
      </ScrollView>
      
      <FAB
        style={styles.fab}
        icon="plus"
        label="Ödeme Ekle"
        onPress={openAddPaymentDialog}
      />

      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>Müşteriyi Sil</Dialog.Title>
          <Dialog.Content>
            <Text>
              "{customer?.name}" isimli müşteriyi silmek istediğinize emin misiniz?
              Bu işlem geri alınamaz ve müşteriye ait tüm işlem kayıtları da silinecektir.
            </Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>İptal</Button>
            <Button onPress={handleDelete} textColor="red">Sil</Button>
          </Dialog.Actions>
        </Dialog>

        <Dialog visible={addPaymentDialogVisible} onDismiss={() => setAddPaymentDialogVisible(false)}>
          <Dialog.Title>Yeni Ödeme Ekle</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label="Miktar (TL) *"
              value={paymentAmount}
              onChangeText={setPaymentAmount}
              keyboardType="decimal-pad"
              style={styles.dialogInput}
            />
            <TextInput
              label="Açıklama"
              value={paymentDescription}
              onChangeText={setPaymentDescription}
              style={styles.dialogInput}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setAddPaymentDialogVisible(false)}>İptal</Button>
            <Button 
              onPress={handleAddPayment} 
              disabled={isSavingPayment}
              loading={isSavingPayment}
            >
              Ekle
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
}

// This component is required for the dialog
function TextInput({ label, value, onChangeText, keyboardType, style }) {
  return (
    <View style={[style, { marginBottom: 15 }]}>
      <Text style={{ marginBottom: 5, fontWeight: '500' }}>{label}</Text>
      <View 
        style={{ 
          borderWidth: 1, 
          borderColor: '#ccc', 
          borderRadius: 5, 
          padding: 10 
        }}
      >
        <TextInput
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType || 'default'}
          style={{ fontSize: 16 }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 80,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
  },
  actionButton: {
    margin: 0,
  },
  infoCard: {
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoText: {
    fontSize: 16,
    marginLeft: 10,
    flex: 1,
  },
  summaryCard: {
    marginBottom: 16,
    backgroundColor: '#e3f2fd',
  },
  totalAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1976d2',
  },
  sectionTitle: {
    marginBottom: 12,
  },
  transactionsCard: {
    marginBottom: 16,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  transactionDetails: {
    flex: 1,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: '500',
  },
  transactionDate: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4caf50',
  },
  divider: {
    height: 1,
    backgroundColor: '#e0e0e0',
  },
  emptyText: {
    textAlign: 'center',
    marginVertical: 20,
    color: '#666',
    fontStyle: 'italic',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
  dialogInput: {
    marginBottom: 15,
  },
});