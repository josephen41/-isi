import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { Text, TextInput, Button, useTheme, ActivityIndicator } from 'react-native-paper';
import { useLocalSearchParams, router } from 'expo-router';
import { addProduct, updateProduct, getProductById } from '@/utils/asyncStorage';

export default function ProductFormScreen() {
  const { productId } = useLocalSearchParams();
  const theme = useTheme();
  const [loading, setLoading] = useState(!!productId);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    price: '',
    stock: '',
    description: '',
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (productId) {
      loadProduct();
    }
  }, [productId]);

  const loadProduct = async () => {
    try {
      const product = await getProductById(productId);
      if (product) {
        setFormData({
          name: product.name || '',
          category: product.category || '',
          price: product.price ? String(product.price) : '',
          stock: product.stock ? String(product.stock) : '',
          description: product.description || '',
        });
      }
    } catch (error) {
      console.error('Error loading product:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when user types
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Ürün adı gerekli';
    }
    
    if (!formData.price.trim()) {
      newErrors.price = 'Fiyat gerekli';
    } else if (isNaN(parseFloat(formData.price)) || parseFloat(formData.price) <= 0) {
      newErrors.price = 'Geçerli bir fiyat giriniz';
    }
    
    if (formData.stock.trim() && (isNaN(parseInt(formData.stock)) || parseInt(formData.stock) < 0)) {
      newErrors.stock = 'Geçerli bir stok miktarı giriniz';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    try {
      setSaving(true);
      
      const processedData = {
        ...formData,
        price: parseFloat(formData.price),
        stock: formData.stock ? parseInt(formData.stock) : 0,
      };
      
      if (productId) {
        await updateProduct(productId, processedData);
      } else {
        await addProduct(processedData);
      }
      
      router.back();
    } catch (error) {
      console.error('Error saving product:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
        <Text style={styles.title}>
          {productId ? 'Ürün Düzenle' : 'Yeni Ürün Ekle'}
        </Text>
        
        <TextInput
          label="Ürün Adı *"
          value={formData.name}
          onChangeText={(value) => handleChange('name', value)}
          style={styles.input}
          error={!!errors.name}
        />
        {errors.name ? <Text style={styles.errorText}>{errors.name}</Text> : null}
        
        <TextInput
          label="Kategori"
          value={formData.category}
          onChangeText={(value) => handleChange('category', value)}
          style={styles.input}
        />
        
        <TextInput
          label="Fiyat (TL) *"
          value={formData.price}
          onChangeText={(value) => handleChange('price', value)}
          keyboardType="decimal-pad"
          style={styles.input}
          error={!!errors.price}
        />
        {errors.price ? <Text style={styles.errorText}>{errors.price}</Text> : null}
        
        <TextInput
          label="Stok Miktarı"
          value={formData.stock}
          onChangeText={(value) => handleChange('stock', value)}
          keyboardType="number-pad"
          style={styles.input}
          error={!!errors.stock}
        />
        {errors.stock ? <Text style={styles.errorText}>{errors.stock}</Text> : null}
        
        <TextInput
          label="Açıklama"
          value={formData.description}
          onChangeText={(value) => handleChange('description', value)}
          multiline
          numberOfLines={3}
          style={styles.input}
        />
        
        <View style={styles.buttonsContainer}>
          <Button
            mode="contained"
            onPress={handleSubmit}
            style={styles.submitButton}
            disabled={saving}
            loading={saving}
          >
            {productId ? 'Güncelle' : 'Kaydet'}
          </Button>
          
          <Button
            mode="outlined"
            onPress={() => router.back()}
            style={styles.cancelButton}
            disabled={saving}
          >
            İptal
          </Button>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: 16,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    marginBottom: 12,
    backgroundColor: 'white',
  },
  errorText: {
    color: 'red',
    marginTop: -10,
    marginBottom: 10,
    marginLeft: 8,
    fontSize: 12,
  },
  buttonsContainer: {
    flexDirection: 'column',
    marginTop: 20,
  },
  submitButton: {
    marginBottom: 12,
  },
  cancelButton: {
    marginBottom: 40,
  },
});