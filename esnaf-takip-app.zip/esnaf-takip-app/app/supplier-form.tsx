import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { Text, TextInput, Button, useTheme, ActivityIndicator } from 'react-native-paper';
import { useLocalSearchParams, router } from 'expo-router';
import { addSupplier, updateSupplier, getSupplierById } from '@/utils/asyncStorage';

export default function SupplierFormScreen() {
  const { supplierId } = useLocalSearchParams();
  const theme = useTheme();
  const [loading, setLoading] = useState(!!supplierId);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    notes: '',
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (supplierId) {
      loadSupplier();
    }
  }, [supplierId]);

  const loadSupplier = async () => {
    try {
      const supplier = await getSupplierById(supplierId);
      if (supplier) {
        setFormData({
          name: supplier.name || '',
          phone: supplier.phone || '',
          email: supplier.email || '',
          address: supplier.address || '',
          notes: supplier.notes || '',
        });
      }
    } catch (error) {
      console.error('Error loading supplier:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when user types
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Tedarikçi adı gerekli';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Telefon numarası gerekli';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    try {
      setSaving(true);
      
      if (supplierId) {
        await updateSupplier(supplierId, formData);
      } else {
        await addSupplier(formData);
      }
      
      router.back();
    } catch (error) {
      console.error('Error saving supplier:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
        <Text style={styles.title}>
          {supplierId ? 'Tedarikçi Düzenle' : 'Yeni Tedarikçi Ekle'}
        </Text>
        
        <TextInput
          label="Tedarikçi Adı *"
          value={formData.name}
          onChangeText={(value) => handleChange('name', value)}
          style={styles.input}
          error={!!errors.name}
        />
        {errors.name ? <Text style={styles.errorText}>{errors.name}</Text> : null}
        
        <TextInput
          label="Telefon *"
          value={formData.phone}
          onChangeText={(value) => handleChange('phone', value)}
          keyboardType="phone-pad"
          style={styles.input}
          error={!!errors.phone}
        />
        {errors.phone ? <Text style={styles.errorText}>{errors.phone}</Text> : null}
        
        <TextInput
          label="E-posta"
          value={formData.email}
          onChangeText={(value) => handleChange('email', value)}
          keyboardType="email-address"
          style={styles.input}
        />
        
        <TextInput
          label="Adres"
          value={formData.address}
          onChangeText={(value) => handleChange('address', value)}
          multiline
          numberOfLines={3}
          style={styles.input}
        />
        
        <TextInput
          label="Notlar"
          value={formData.notes}
          onChangeText={(value) => handleChange('notes', value)}
          multiline
          numberOfLines={3}
          style={styles.input}
        />
        
        <View style={styles.buttonsContainer}>
          <Button
            mode="contained"
            onPress={handleSubmit}
            style={styles.submitButton}
            disabled={saving}
            loading={saving}
          >
            {supplierId ? 'Güncelle' : 'Kaydet'}
          </Button>
          
          <Button
            mode="outlined"
            onPress={() => router.back()}
            style={styles.cancelButton}
            disabled={saving}
          >
            İptal
          </Button>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: 16,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    marginBottom: 12,
    backgroundColor: 'white',
  },
  errorText: {
    color: 'red',
    marginTop: -10,
    marginBottom: 10,
    marginLeft: 8,
    fontSize: 12,
  },
  buttonsContainer: {
    flexDirection: 'column',
    marginTop: 20,
  },
  submitButton: {
    marginBottom: 12,
  },
  cancelButton: {
    marginBottom: 40,
  },
});