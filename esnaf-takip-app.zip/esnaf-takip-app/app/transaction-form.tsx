import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import {
  Text, TextInput, Button, useTheme, ActivityIndicator,
  SegmentedButtons, Menu, Divider
} from 'react-native-paper';
import { useLocalSearchParams, router } from 'expo-router';
import { 
  addTransaction, getTransactionById, updateTransaction,
  getCustomers, getSuppliers
} from '@/utils/asyncStorage';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function TransactionFormScreen() {
  const { transactionId, entityId, entityType } = useLocalSearchParams();
  const theme = useTheme();
  const [loading, setLoading] = useState(!!transactionId);
  const [saving, setSaving] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [menuVisible, setMenuVisible] = useState(false);
  
  const [formData, setFormData] = useState({
    type: entityType || 'customer',
    customerOrSupplierId: entityId || '',
    amount: '',
    date: new Date().toISOString().split('T')[0], // Today's date in YYYY-MM-DD format
    description: '',
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    loadData();
    if (transactionId) {
      loadTransaction();
    }
  }, [transactionId]);

  const loadData = async () => {
    try {
      const [customersData, suppliersData] = await Promise.all([
        getCustomers(),
        getSuppliers()
      ]);
      setCustomers(customersData);
      setSuppliers(suppliersData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const loadTransaction = async () => {
    try {
      const transaction = await getTransactionById(transactionId);
      if (transaction) {
        setFormData({
          type: transaction.type || 'customer',
          customerOrSupplierId: transaction.customerOrSupplierId || '',
          amount: transaction.amount ? String(transaction.amount) : '',
          date: transaction.date || new Date().toISOString().split('T')[0],
          description: transaction.description || '',
        });
      }
    } catch (error) {
      console.error('Error loading transaction:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when user types
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.customerOrSupplierId) {
      newErrors.customerOrSupplierId = 
        formData.type === 'customer' ? 'Lütfen bir müşteri seçin' : 'Lütfen bir tedarikçi seçin';
    }
    
    if (!formData.amount.trim()) {
      newErrors.amount = 'Tutar gerekli';
    } else if (isNaN(parseFloat(formData.amount)) || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Geçerli bir tutar giriniz';
    }
    
    if (!formData.date) {
      newErrors.date = 'Tarih gerekli';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    try {
      setSaving(true);
      
      const processedData = {
        ...formData,
        amount: parseFloat(formData.amount),
      };
      
      if (transactionId) {
        await updateTransaction(transactionId, processedData);
      } else {
        await addTransaction(processedData);
      }
      
      router.back();
    } catch (error) {
      console.error('Error saving transaction:', error);
    } finally {
      setSaving(false);
    }
  };

  const toggleMenu = () => setMenuVisible(!menuVisible);

  const selectEntity = (id, name) => {
    handleChange('customerOrSupplierId', id);
    setMenuVisible(false);
  };

  const getEntityName = () => {
    const entities = formData.type === 'customer' ? customers : suppliers;
    const entity = entities.find(e => e.id === formData.customerOrSupplierId);
    return entity ? entity.name : 'Seçiniz';
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  const entityList = formData.type === 'customer' ? customers : suppliers;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
        <Text style={styles.title}>
          {transactionId ? 'İşlemi Düzenle' : 'Yeni İşlem Ekle'}
        </Text>
        
        <SegmentedButtons
          value={formData.type}
          onValueChange={(value) => {
            handleChange('type', value);
            handleChange('customerOrSupplierId', '');
          }}
          buttons={[
            {
              value: 'customer',
              label: 'Alacak',
              icon: 'account',
              style: {
                backgroundColor: formData.type === 'customer' ? '#e8f5e9' : undefined,
              }
            },
            {
              value: 'supplier',
              label: 'Borç',
              icon: 'truck',
              style: {
                backgroundColor: formData.type === 'supplier' ? '#ffebee' : undefined,
              }
            },
          ]}
          style={styles.segmentedButtons}
        />
        
        <View style={styles.entitySelector}>
          <Text style={styles.inputLabel}>
            {formData.type === 'customer' ? 'Müşteri' : 'Tedarikçi'} *
          </Text>
          <Button
            mode="outlined"
            icon={formData.type === 'customer' ? 'account' : 'truck'}
            onPress={toggleMenu}
            style={[
              styles.entityButton, 
              errors.customerOrSupplierId ? styles.inputError : null
            ]}
            contentStyle={styles.entityButtonContent}
          >
            {getEntityName()}
          </Button>
          {errors.customerOrSupplierId ? (
            <Text style={styles.errorText}>{errors.customerOrSupplierId}</Text>
          ) : null}

          <Menu
            visible={menuVisible}
            onDismiss={() => setMenuVisible(false)}
            anchor={{ x: 0, y: 0 }}
            style={styles.menu}
          >
            {entityList.length === 0 ? (
              <Menu.Item 
                title={`Henüz ${formData.type === 'customer' ? 'müşteri' : 'tedarikçi'} kaydı bulunmuyor`}
                disabled={true}
              />
            ) : (
              entityList.map((entity) => (
                <Menu.Item
                  key={entity.id}
                  title={entity.name}
                  onPress={() => selectEntity(entity.id, entity.name)}
                />
              ))
            )}
          </Menu>
        </View>
        
        <TextInput
          label="Tutar (TL) *"
          value={formData.amount}
          onChangeText={(value) => handleChange('amount', value)}
          keyboardType="decimal-pad"
          style={styles.input}
          error={!!errors.amount}
        />
        {errors.amount ? <Text style={styles.errorText}>{errors.amount}</Text> : null}
        
        <TextInput
          label="Tarih *"
          value={formData.date}
          onChangeText={(value) => handleChange('date', value)}
          style={styles.input}
          placeholder="YYYY-MM-DD"
          error={!!errors.date}
        />
        {errors.date ? <Text style={styles.errorText}>{errors.date}</Text> : null}
        
        <TextInput
          label="Açıklama"
          value={formData.description}
          onChangeText={(value) => handleChange('description', value)}
          multiline
          numberOfLines={3}
          style={styles.input}
        />
        
        <View style={styles.buttonsContainer}>
          <Button
            mode="contained"
            onPress={handleSubmit}
            style={styles.submitButton}
            disabled={saving}
            loading={saving}
          >
            {transactionId ? 'Güncelle' : 'Kaydet'}
          </Button>
          
          <Button
            mode="outlined"
            onPress={() => router.back()}
            style={styles.cancelButton}
            disabled={saving}
          >
            İptal
          </Button>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  contentContainer: {
    padding: 16,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  segmentedButtons: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
    marginLeft: 12,
  },
  entitySelector: {
    marginBottom: 16,
  },
  entityButton: {
    justifyContent: 'flex-start',
    borderColor: '#ccc',
  },
  entityButtonContent: {
    justifyContent: 'flex-start',
  },
  menu: {
    marginTop: 70,
    maxHeight: 300,
  },
  input: {
    marginBottom: 12,
    backgroundColor: 'white',
  },
  inputError: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    marginTop: 2,
    marginBottom: 10,
    marginLeft: 12,
    fontSize: 12,
  },
  buttonsContainer: {
    flexDirection: 'column',
    marginTop: 20,
  },
  submitButton: {
    marginBottom: 12,
  },
  cancelButton: {
    marginBottom: 40,
  },
});