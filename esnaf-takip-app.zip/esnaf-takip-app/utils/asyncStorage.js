import AsyncStorage from '@react-native-async-storage/async-storage';
import { v4 as uuidv4 } from 'uuid';

// Storage keys
const KEYS = {
  CUSTOMERS: 'customers',
  SUPPLIERS: 'suppliers',
  PRODUCTS: 'products',
  TRANSACTIONS: 'transactions',
};

// Initialize storage with default empty arrays if not exists
export const initializeStorage = async () => {
  try {
    const keys = Object.values(KEYS);
    const promises = keys.map(async (key) => {
      const value = await AsyncStorage.getItem(key);
      if (value === null) {
        await AsyncStorage.setItem(key, JSON.stringify([]));
      }
    });
    await Promise.all(promises);
    console.log('Storage initialized');
  } catch (error) {
    console.error('Error initializing storage:', error);
  }
};

// Customer CRUD operations
export const getCustomers = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(KEYS.CUSTOMERS);
    return jsonValue !== null ? JSON.parse(jsonValue) : [];
  } catch (error) {
    console.error('Error getting customers:', error);
    return [];
  }
};

export const getCustomerById = async (id) => {
  try {
    const customers = await getCustomers();
    return customers.find(customer => customer.id === id) || null;
  } catch (error) {
    console.error('Error getting customer by id:', error);
    return null;
  }
};

export const addCustomer = async (customer) => {
  try {
    const customers = await getCustomers();
    const newCustomer = {
      ...customer,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    customers.push(newCustomer);
    await AsyncStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customers));
    return newCustomer;
  } catch (error) {
    console.error('Error adding customer:', error);
    throw error;
  }
};

export const updateCustomer = async (id, updatedCustomer) => {
  try {
    const customers = await getCustomers();
    const index = customers.findIndex(customer => customer.id === id);
    if (index !== -1) {
      customers[index] = {
        ...customers[index],
        ...updatedCustomer,
        updatedAt: new Date().toISOString(),
      };
      await AsyncStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customers));
      return customers[index];
    }
    throw new Error('Customer not found');
  } catch (error) {
    console.error('Error updating customer:', error);
    throw error;
  }
};

export const deleteCustomer = async (id) => {
  try {
    const customers = await getCustomers();
    const filteredCustomers = customers.filter(customer => customer.id !== id);
    await AsyncStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(filteredCustomers));
    
    // Delete associated transactions
    const transactions = await getAllTransactions();
    const filteredTransactions = transactions.filter(
      transaction => 
        !(transaction.type === 'customer' && transaction.customerOrSupplierId === id)
    );
    await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(filteredTransactions));
  } catch (error) {
    console.error('Error deleting customer:', error);
    throw error;
  }
};

// Supplier CRUD operations
export const getSuppliers = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(KEYS.SUPPLIERS);
    return jsonValue !== null ? JSON.parse(jsonValue) : [];
  } catch (error) {
    console.error('Error getting suppliers:', error);
    return [];
  }
};

export const getSupplierById = async (id) => {
  try {
    const suppliers = await getSuppliers();
    return suppliers.find(supplier => supplier.id === id) || null;
  } catch (error) {
    console.error('Error getting supplier by id:', error);
    return null;
  }
};

export const addSupplier = async (supplier) => {
  try {
    const suppliers = await getSuppliers();
    const newSupplier = {
      ...supplier,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    suppliers.push(newSupplier);
    await AsyncStorage.setItem(KEYS.SUPPLIERS, JSON.stringify(suppliers));
    return newSupplier;
  } catch (error) {
    console.error('Error adding supplier:', error);
    throw error;
  }
};

export const updateSupplier = async (id, updatedSupplier) => {
  try {
    const suppliers = await getSuppliers();
    const index = suppliers.findIndex(supplier => supplier.id === id);
    if (index !== -1) {
      suppliers[index] = {
        ...suppliers[index],
        ...updatedSupplier,
        updatedAt: new Date().toISOString(),
      };
      await AsyncStorage.setItem(KEYS.SUPPLIERS, JSON.stringify(suppliers));
      return suppliers[index];
    }
    throw new Error('Supplier not found');
  } catch (error) {
    console.error('Error updating supplier:', error);
    throw error;
  }
};

export const deleteSupplier = async (id) => {
  try {
    const suppliers = await getSuppliers();
    const filteredSuppliers = suppliers.filter(supplier => supplier.id !== id);
    await AsyncStorage.setItem(KEYS.SUPPLIERS, JSON.stringify(filteredSuppliers));
    
    // Delete associated transactions
    const transactions = await getAllTransactions();
    const filteredTransactions = transactions.filter(
      transaction => 
        !(transaction.type === 'supplier' && transaction.customerOrSupplierId === id)
    );
    await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(filteredTransactions));
  } catch (error) {
    console.error('Error deleting supplier:', error);
    throw error;
  }
};

// Product CRUD operations
export const getProducts = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(KEYS.PRODUCTS);
    return jsonValue !== null ? JSON.parse(jsonValue) : [];
  } catch (error) {
    console.error('Error getting products:', error);
    return [];
  }
};

export const getProductById = async (id) => {
  try {
    const products = await getProducts();
    return products.find(product => product.id === id) || null;
  } catch (error) {
    console.error('Error getting product by id:', error);
    return null;
  }
};

export const addProduct = async (product) => {
  try {
    const products = await getProducts();
    const newProduct = {
      ...product,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    products.push(newProduct);
    await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
    return newProduct;
  } catch (error) {
    console.error('Error adding product:', error);
    throw error;
  }
};

export const updateProduct = async (id, updatedProduct) => {
  try {
    const products = await getProducts();
    const index = products.findIndex(product => product.id === id);
    if (index !== -1) {
      products[index] = {
        ...products[index],
        ...updatedProduct,
        updatedAt: new Date().toISOString(),
      };
      await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
      return products[index];
    }
    throw new Error('Product not found');
  } catch (error) {
    console.error('Error updating product:', error);
    throw error;
  }
};

export const deleteProduct = async (id) => {
  try {
    const products = await getProducts();
    const filteredProducts = products.filter(product => product.id !== id);
    await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(filteredProducts));
  } catch (error) {
    console.error('Error deleting product:', error);
    throw error;
  }
};

// Transaction CRUD operations
export const getAllTransactions = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(KEYS.TRANSACTIONS);
    return jsonValue !== null ? JSON.parse(jsonValue) : [];
  } catch (error) {
    console.error('Error getting transactions:', error);
    return [];
  }
};

export const getTransactionById = async (id) => {
  try {
    const transactions = await getAllTransactions();
    return transactions.find(transaction => transaction.id === id) || null;
  } catch (error) {
    console.error('Error getting transaction by id:', error);
    return null;
  }
};

export const getTransactionsByEntityId = async (entityId, type) => {
  try {
    const transactions = await getAllTransactions();
    return transactions.filter(
      transaction => 
        transaction.type === type && 
        transaction.customerOrSupplierId === entityId
    );
  } catch (error) {
    console.error('Error getting transactions by entity id:', error);
    return [];
  }
};

export const addTransaction = async (transaction) => {
  try {
    const transactions = await getAllTransactions();
    let entityName = '';
    
    // Get entity name based on type
    if (transaction.type === 'customer') {
      const customer = await getCustomerById(transaction.customerOrSupplierId);
      if (customer) {
        entityName = customer.name;
      }
    } else if (transaction.type === 'supplier') {
      const supplier = await getSupplierById(transaction.customerOrSupplierId);
      if (supplier) {
        entityName = supplier.name;
      }
    }
    
    const newTransaction = {
      ...transaction,
      id: uuidv4(),
      entityName,
      createdAt: new Date().toISOString(),
    };
    transactions.push(newTransaction);
    await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(transactions));
    return newTransaction;
  } catch (error) {
    console.error('Error adding transaction:', error);
    throw error;
  }
};

export const updateTransaction = async (id, updatedTransaction) => {
  try {
    const transactions = await getAllTransactions();
    const index = transactions.findIndex(transaction => transaction.id === id);
    if (index !== -1) {
      transactions[index] = {
        ...transactions[index],
        ...updatedTransaction,
        updatedAt: new Date().toISOString(),
      };
      await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(transactions));
      return transactions[index];
    }
    throw new Error('Transaction not found');
  } catch (error) {
    console.error('Error updating transaction:', error);
    throw error;
  }
};

export const deleteTransaction = async (id) => {
  try {
    const transactions = await getAllTransactions();
    const filteredTransactions = transactions.filter(transaction => transaction.id !== id);
    await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(filteredTransactions));
  } catch (error) {
    console.error('Error deleting transaction:', error);
    throw error;
  }
};

// Dashboard functions
export const getDashboardStats = async () => {
  try {
    // Get all data
    const customers = await getCustomers();
    const suppliers = await getSuppliers();
    const products = await getProducts();
    const transactions = await getAllTransactions();
    
    // Calculate metrics
    const totalEarnings = transactions
      .filter(t => t.type === 'customer')
      .reduce((total, t) => total + parseFloat(t.amount), 0);
    
    const totalExpenses = transactions
      .filter(t => t.type === 'supplier')
      .reduce((total, t) => total + parseFloat(t.amount), 0);
    
    const profit = totalEarnings - totalExpenses;
    
    // Get recent transactions (last 5)
    const recentTransactions = [...transactions]
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 5);
    
    return {
      customersCount: customers.length,
      suppliersCount: suppliers.length,
      productsCount: products.length,
      transactionsCount: transactions.length,
      totalEarnings,
      totalExpenses,
      profit,
      recentTransactions,
    };
  } catch (error) {
    console.error('Error getting dashboard stats:', error);
    return {
      customersCount: 0,
      suppliersCount: 0,
      productsCount: 0,
      transactionsCount: 0,
      totalEarnings: 0,
      totalExpenses: 0,
      profit: 0,
      recentTransactions: [],
    };
  }
};